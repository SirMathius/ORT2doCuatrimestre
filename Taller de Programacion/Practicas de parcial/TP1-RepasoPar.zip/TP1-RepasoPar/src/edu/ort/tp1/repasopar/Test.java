/**
 * 
 */
package edu.ort.tp1.repasopar;

import java.util.InputMismatchException;
import java.util.Scanner;

public class Test {
	private final static int CANT_SOLICITUDES_MAX=10;
	
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		
		// 1.	Crear "bancoRio" donde la cantidad de solicitudes sea CANT_SOLICITUDES_MAX.
		
		//Completar
		
		//	2.	Crear el Banco bancoGalicia utilizando el metodo pedirCantSolicitudesMaximas donde 
		//      primero se le ingrese una letra y luego se ingrese el valor 1.
	
		//Completar


		// 3.	Llamar al metodo procesarSolicitudes. 
		
		//Completar
		
		
		// 4.	Llamar a	mostrarColaSolicitudes()
		
		System.out.println("--------------------");
		System.out.println("PUNTO 4:");
		//Completar
		
		input.close();
	}
	/* 6) public static int pedirCantSolicitudesMaximas(Scanner scanner)
	Tal que pida el ingreso por teclado de la cantidad de solicitudes maximas, capture la excepcion en caso 
	de ingresar algun valor que no sea numerico y vuelva a pedir el ingreso por teclado hasta que reciba un dato valido.
	*/
	public static int pedirCantSolicitudesMaximas(Scanner scanner){
		int cantSolMaxima = 0;
		
		//Completar
		
		return cantSolMaxima;
	}  	
}