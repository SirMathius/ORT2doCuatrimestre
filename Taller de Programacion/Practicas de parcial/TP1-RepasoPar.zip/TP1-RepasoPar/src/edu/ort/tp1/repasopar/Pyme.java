/**
 * 
 */
package edu.ort.tp1.repasopar;

public class Pyme {
	private final int MAX_VALOR = 10;
	private String 	cuit;
	private String	razonSocial;
	private int 	cantVentasAnuales;
	
	// 1
	public Pyme(String codigo, String cuit, String razonSocial, int cantVentasAnuales) {
		//Completar

	}
	
	public String getCuit() {
		return cuit;
	}

	public void setCuit(String cuit) {
		this.cuit = cuit;
	}

	public String getRazonSocial() {
		return razonSocial;
	}

	public void setRazonSocial(String razonSocial) {
		this.razonSocial = razonSocial;
	}
	
	public int getVentasAnuales() {
		return cantVentasAnuales;
	}

	public void setVentasAnuales(int cantVentasAnuales) {
		this.cantVentasAnuales = cantVentasAnuales;
	}

	// 2
	@Override
	public double calcularMontoMaximo() {
		// Completar
	}
}
