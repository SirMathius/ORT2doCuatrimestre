package edu.ort.tp1.repasopar;

import java.util.ArrayList;

public class Banco {
	private final static int CANT_CUOTAS = 6;
	private final static int CANT_CLIENTES_MAX = 10;
	private final static int CANT_SOLICITUDES = 5;
	private Solicitud[] solicitudes;
	private ArrayList<Prestamo> prestamos;
	private String[] titulosMatriz;
	private int[][] planCuotasPersona;
	private int[][] planCuotasPyme;
	private Cola<Solicitud> colaSolicitudes;
	
	// 1)Constructor validar obligatoriamente con una excepcion que la cantidad de solicitudes no pueda ser menor o igual a cero.
	public Banco(int cantidadSolicitudes){
		
		//Completar
		
		solicitudes = new Solicitud[cantidadSolicitudes];
		titulosMatriz = new String[] { "Cuota", "Interes", "Iva" };
		prestamos = new ArrayList<Prestamo>();
		colaSolicitudes = new Cola<Solicitud>();
		cargarPlanes();
	}

	public void cargarPlanes() {
		planCuotasPersona = new int[][] { { 1, 30, 3 }, { 2, 28, 3 }, { 3, 26, 3 }, { 4, 24, 3 }, { 5, 20, 3 },	{ 6, 15, 2 } };
		planCuotasPyme = new int[][] { { 1, 15, 5 }, { 2, 14, 5 }, { 3, 13, 5 }, { 4, 12, 5 }, { 5, 11, 5 },{ 6, 10, 5 } };
	}
	/*
	3) public void mostrarColaSolicitudes()
	Recorrer la cola de Solicitudes y mostrar para cada cliente, el CUIT y la razon social en caso de 
	que sea una Pyme o el DNI y el nombre y apellido en caso de que sea Persona, dejando la estructura sin cambios. En 
	ambos casos, mostrar el estado de la solicitud.
	 */
	public void mostrarColaSolicitudes() {
		//Completar
	}
	public int[][] obtenerMatriz(Solicitud solicitud) {
		if (solicitud.getCliente() instanceof Persona)
			return planCuotasPersona;
		else
			return planCuotasPyme;
	}
	public void generarPrestamo(Solicitud solicitud) {
		int[][] planCuotas = obtenerMatriz(solicitud);
		Prestamo prestamo = new Prestamo(solicitud.getCliente());
		Cuota cuota = null;
		for (int i = 0; i < planCuotas.length; i++) {
			for (int j = 0; j < planCuotas[i].length; j++) {
				switch (j) {
				case 0:
					cuota = new Cuota(i + 1);
					break;
				case 1:
					cuota.agregarConcepto(new Concepto(titulosMatriz[j], planCuotas[i][j]));
					break;
				case 2:
					cuota.agregarConcepto(new Concepto(titulosMatriz[j], planCuotas[i][j]));
					break;
				case 3:
					cuota.agregarConcepto(new Concepto(titulosMatriz[j], planCuotas[i][j]));
					break;
				}
			}
			cuota.calcularTotalCuota(solicitud.getMonto());
			prestamo.agregarCuota(cuota);
		}
		agregarPrestamo(prestamo);
	}
	public void agregarSolicitud(Solicitud solicitud, Solicitud[] listaSolicitudes) {
		for (int i = 0; i < listaSolicitudes.length; i++) {
			if (listaSolicitudes[i] == null) {
				listaSolicitudes[i] = solicitud;
				break;
			}
		}
	}
	public void agregarPrestamo(Prestamo prestamo) {
		prestamos.add(prestamo);
	}
	public void procesarSolicitudes() {//, float presupuestoMaximo) {
		

		Cliente[] cli = new Cliente[CANT_CLIENTES_MAX];
		Solicitud[] solicitudes = new Solicitud[CANT_SOLICITUDES];

		cli[0] = new Persona("1", "100", "Jose Nil", 10000);
		cli[1] = new Persona("2", "200", "Hebe Lis", 5000);
		cli[2] = new Pyme("3", "300", "Jorgito", 10000);
		cli[3] = new Pyme("4", "400", "El Tala", 20000);
		cli[4] = new Pyme("5", "500", "Alpargatas", 50000);


		solicitudes[0] = new Solicitud(cli[0], 20000, "01/05/2019");
		solicitudes[1] = new Solicitud(cli[1], 30000, "02/05/2019");
		solicitudes[2] = new Solicitud(cli[2], 1000000, "03/05/2019");
		solicitudes[3] = new Solicitud(cli[3], 200000, "04/05/2019");
		solicitudes[4] = new Solicitud(cli[4], 400000, "05/05/2019");
		
		
		
		this.solicitudes = solicitudes;
		for (int i = 0; i < solicitudes.length; i++) {
			if (solicitudes[i] != null) {
				if (solicitudes[i].getMonto() <= solicitudes[i].getCliente().calcularMontoMaximo()) {
						solicitudes[i].setEstado(EstadoSolicitud.APROBADA);
						generarPrestamo(solicitudes[i]);// Si la solicitud fue aprobada, se genera un credito
				} else {
					solicitudes[i].setEstado(EstadoSolicitud.RECHAZADA);
				}
				agregarSolicitud(solicitudes[i], this.solicitudes);
			}
			colaSolicitudes.add(solicitudes[i]);
		}
	}
}