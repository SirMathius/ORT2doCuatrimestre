package edu.ort.tp1.repasopar;

import java.util.ArrayList;

public class Cuota {
	private final static int CANT_CUOTAS=6;
	private 	int 					numero;
	private  	ArrayList<Concepto>  	conceptos;
	private		float					totalCuota;
	
	public Cuota(int numero) {
		this.numero = numero;
		totalCuota 	= 0;
		conceptos = new ArrayList<Concepto>();
	}
	
	//Ej: Si una Persona pide un cr�dito de $5000, el primer mes deber� pagar: (5000/6)+(5000/6)*0.12+(5000/6)*0.01+(5000/6)*0.03
	public void calcularTotalCuota(float montoSolicitado) {
		totalCuota += (montoSolicitado/CANT_CUOTAS);
		for(int i=0; i<conceptos.size();i++) {
			totalCuota += (montoSolicitado/CANT_CUOTAS)*(conceptos.get(i).getMonto()/100);
		}
	}

	public int getNumero() {
		return numero;
	}
	
	public void setNumero(int numero) {
		this.numero = numero;
	}
	
	public ArrayList<Concepto> getConceptos() {
		return conceptos;
	}
	
	public void agregarConcepto(Concepto concepto) {
		conceptos.add(concepto);
	}

	
	public float getTotalCuota() {
		return totalCuota;
	}

	public void setTotalCuota(float totalCuota) {
		this.totalCuota = totalCuota;
	}

	@Override
	public String toString() {
		return "Detalle de la cuota " + String.valueOf(numero) + ": Monto: " + String.format("%.2f", totalCuota);
	}
}