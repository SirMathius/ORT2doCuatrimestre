package edu.ort.tp1.repasopar;

public class Solicitud {
	
	private Cliente 			cliente;
	private float				monto;
	private String				fecha;
	private EstadoSolicitud 	estado;
	
	public Solicitud(Cliente cliente, float monto, String fecha) {
		this.cliente = cliente;
		this.monto = monto;
		this.fecha = fecha;
		this.estado = EstadoSolicitud.PRESENTADA
;
	}
	public Cliente getCliente() {
		return cliente;
	}

	public void setCliente(Cliente cliente) {
		this.cliente = cliente;
	}

	public float getMonto() {
		return monto;
	}

	public void setMonto(float monto) {
		this.monto = monto;
	}

	public String getFecha() {
		return fecha;
	}

	public void setFecha(String fecha) {
		this.fecha = fecha;
	}

	public EstadoSolicitud getEstado() {
		return estado;
	}

	public void setEstado(EstadoSolicitud estado) {
		this.estado = estado;
	}
	@Override
	public String toString() {
		return "SolicitudPrestamo [cliente=" + cliente + ", monto=" + monto + ", fecha=" + fecha + ", estado=" + estado + "]";
	}
}
