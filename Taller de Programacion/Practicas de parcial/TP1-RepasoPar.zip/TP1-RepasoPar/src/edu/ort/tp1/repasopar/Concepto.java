package edu.ort.tp1.repasopar;

public class Concepto {
	
	private String 	nombre;
	private float	monto;
	
	public Concepto(String nombre, float monto) {
		this.nombre = nombre;
		this.monto = monto;
	}

	public String getNombre() {
		return nombre;
	}
	
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	
	public float getMonto() {
		return monto;
	}
	
	public void setMonto(float monto) {
		this.monto = monto;
	}	
}