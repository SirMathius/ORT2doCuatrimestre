/**
 * 
 */
package edu.ort.tp1.repasopar;

public abstract class Cliente {
	private String codigo;
	private Solicitud solicitud;

	public Cliente(String codigo) {
		this.codigo = codigo;
	}
	
	public String getCodigo() {
		return codigo;
	}
	
	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}
	
	@Override
	public String toString() {
		return "Cliente [codigo=" + codigo + "]";
	}
	
	public abstract double calcularMontoMaximo();
}
