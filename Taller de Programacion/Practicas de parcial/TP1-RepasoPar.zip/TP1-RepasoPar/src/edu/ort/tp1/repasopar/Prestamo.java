package edu.ort.tp1.repasopar;
import java.util.ArrayList;

public class Prestamo{
	private Cliente 			cliente;
	private ArrayList<Cuota> 	cuotas;
	
    public Prestamo(Cliente cliente){
        this.cliente 	= cliente;
        cuotas 	= new ArrayList<Cuota>(6);
    }
    
    public void agregarCuota(Cuota cuota) {
    	cuotas.add(cuota);
    }
    
	public ArrayList<Cuota> getCuotas() {
		return cuotas;
	}
	
	public Cliente getCliente() {
		return cliente;
	}
	
	@Override
	public String toString() {
		return "";
	}
}