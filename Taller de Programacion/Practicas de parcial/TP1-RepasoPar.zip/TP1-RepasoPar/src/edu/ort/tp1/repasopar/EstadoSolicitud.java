package edu.ort.tp1.repasopar;

public enum EstadoSolicitud {
	PRESENTADA,
    APROBADA,
    RECHAZADA;	
}