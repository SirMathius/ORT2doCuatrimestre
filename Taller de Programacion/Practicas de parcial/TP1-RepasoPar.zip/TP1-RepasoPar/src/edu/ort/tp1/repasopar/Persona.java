package edu.ort.tp1.repasopar;

public class Persona {
	private final 	int MAX_MONTO=4;
	private String 	dni;
	private String 	nombreApellido;
	private float 	sueldoBruto;
	
	// 1
	public Persona(String codigo, String dni, String nombreApellido, float sueldoBruto) {
		//Completar

	}
	
	public String getDni() {
		return dni;
	}

	public void setDni(String dni) {
		this.dni = dni;
	}

	public String getNombreApellido() {
		return nombreApellido;
	}

	public void setNombreApellido(String nombreApellido) {
		this.nombreApellido	= nombreApellido;
	}
	
	public float getSueldoBruto() {
		return sueldoBruto;
	}

	public void setSueldoBruto(float sueldoBruto) {
		this.sueldoBruto = sueldoBruto;
	}
	//2
	@Override
	public double calcularMontoMaximo() {
		
	}
}
