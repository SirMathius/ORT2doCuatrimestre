package ar.edu.ort.tp1.ejer3;

public enum Especialidad {
	
	VELOCIDAD, SALTOS, MARATON, PRUEBAS_COMBINADAS;

}
