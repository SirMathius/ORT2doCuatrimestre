package ar.edu.ort.tp1.ejer3;

public class Atleta {
	
	
	private String nombre;
	private double tiempo;
	
	//Constructor
	public Atleta(String nombre, double tiempo) {
		
		this.nombre = nombre;
		this.tiempo = tiempo;
	}
	
	//getters
	
	public String getNombre() {
		return nombre;
	}
	public double getTiempo() {
		return tiempo;
	}
	
	
	
	
}
