package ar.edu.ort.tp1.ejer2;

public enum Especialidad {
	
	VELOCIDAD, SALTOS, MARATON, PRUEBAS_COMBINADAS;

}
