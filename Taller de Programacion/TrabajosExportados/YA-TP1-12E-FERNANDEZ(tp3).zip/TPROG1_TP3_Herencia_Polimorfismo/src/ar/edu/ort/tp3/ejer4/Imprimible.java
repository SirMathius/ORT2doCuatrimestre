package ar.edu.ort.tp3.ejer4;

public interface Imprimible {

	
	public void imprimir();
}
