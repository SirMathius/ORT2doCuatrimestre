package ar.edu.ort.tp2.ejer2;

public enum TipoDeLinea {
	
	CELULAR, FIJO, FAX;

}
