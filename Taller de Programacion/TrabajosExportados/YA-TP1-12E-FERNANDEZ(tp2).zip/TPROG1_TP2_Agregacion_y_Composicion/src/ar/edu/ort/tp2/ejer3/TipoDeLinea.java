package ar.edu.ort.tp2.ejer3;

public enum TipoDeLinea {
	
	CELULAR, FIJO, FAX;

}
