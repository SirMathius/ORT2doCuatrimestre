package ar.edu.ort.tp2.ejer1;

public enum TipoDeLinea {
	
	CELULAR, FIJO, FAX;

}
