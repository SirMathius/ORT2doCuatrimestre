package ar.edu.ort.tp1.clase2.clases;

public enum EstadoAsiento {
	
	LIBRE, RESERVADO, CUMPLIDO;
}
